Sample attachment file.
